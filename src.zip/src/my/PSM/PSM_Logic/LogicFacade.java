///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package my.PSM.Logic;
//
///**
// *
// * @author clarkep
// */
//public class LogicFacade {
//    
//}
