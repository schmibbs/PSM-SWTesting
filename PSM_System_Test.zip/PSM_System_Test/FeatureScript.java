
import resources.FeatureScriptHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author Admin
 */
public class FeatureScript extends FeatureScriptHelper
{
	/**
	 * Script Name   : <b>FeatureScript</b>
	 * Generated     : <b>Feb 19, 2019 3:56:34 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 14393 ()
	 * 
	 * @since  2019/02/19
	 * @author Admin
	 */
	public void testMain(Object[] args) 
	{
		startApp("PSM");
		
		// Frame: PSM Login
		psmLogin().inputChars("root");
		password().click(atPoint(85,10));
		psmLogin().inputChars("jimmy1993");
		login().click();
		
		// Frame: PSM Main Menu
		features().click();
	}
}

