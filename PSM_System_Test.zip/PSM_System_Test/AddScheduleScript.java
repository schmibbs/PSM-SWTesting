
import resources.AddScheduleScriptHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author Admin
 */
public class AddScheduleScript extends AddScheduleScriptHelper
{
	/**
	 * Script Name   : <b>AddScheduleScript</b>
	 * Generated     : <b>Feb 19, 2019 4:39:36 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 14393 ()
	 * 
	 * @since  2019/02/19
	 * @author Admin
	 */
	public void testMain(Object[] args) 
	{
		startApp("PSM");
		
		// Frame: PSM Login
		psmLogin().inputChars("root");
		password().click(atPoint(104,9));
		psmLogin().inputChars("jimmy1993");
		login().click();
		
		// Frame: PSM Main Menu
		addClassSchedule().click();
		
		// Frame: Schedule Setup
		jComboBox().click();
		jComboBox().click(atText("Spring"));
		startDate().click(atPoint(44,19));
		scheduleSetup().inputChars("1/19/19");
		endDate().click(atPoint(14,3));
		scheduleSetup().inputChars("4/19/19");
		subject().click(atPoint(32,1));
		scheduleSetup().inputChars("CEN");
		courseNumber().click(atPoint(47,14));
		courseNumber().hover(atPoint(47,14));
		scheduleSetup().inputKeys("C{BKSP}4567");
		courseName().click(atPoint(251,1));
		courseName().hover(atPoint(251,1));
		scheduleSetup().inputKeys("my class{BKSP}{BKSP}{BKSP}{BKSP}{BKSP}{BKSP}Class");
		jTextField().click(atPoint(27,3));
		scheduleSetup().inputChars("5:00");
		endTime().doubleClick(atPoint(5,2));
		scheduleSetup().inputChars("6:00");
		wednesday().click(atPoint(25,10));
		scheduleSetup().inputChars("5:00");
		jTextField2().click(atPoint(26,10));
		scheduleSetup().inputChars("6:00");
		save().click();
		
		// Frame: PSM Main Menu
		logout().click();
		
		// Frame: System Message
		ok(ANY,MAY_EXIT).click();
	}
}

