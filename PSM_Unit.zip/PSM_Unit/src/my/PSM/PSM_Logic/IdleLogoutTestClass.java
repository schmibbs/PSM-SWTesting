/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package my.PSM.PSM_Logic;

/**
 *
 * @author Kurt
 */
public class IdleLogoutTestClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
