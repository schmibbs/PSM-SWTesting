package my.PSM.PSM_Storage;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

import java.sql.SQLException;
import java.util.ArrayList;

import static org.mockito.Mockito.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class DBConnectionTest {
	
	@Mock
	Statement statementMock;
	@Mock
	ResultSet resultMock;
	@Mock
	Connection connectMock;
	
	
	@Rule public MockitoRule mockitoRule = MockitoJUnit.rule();
	
	private DBConnection db;
	
	
	
	@Before
	public void setUp() throws Exception {
		statementMock = mock(Statement.class);
		resultMock = mock(ResultSet.class);
		connectMock = mock(Connection.class);
		
		db = new DBConnection();		
		
		db.setDependency(connectMock);
	}

	@After
	public void tearDown() throws Exception {
		db = null;
	}

	@Test
	public void testConnectStringStringConnection() {
		assertEquals(0, db.connect("user", "pw", connectMock));
	}
	@Test
	public void testDisconnect() 
	{
		assertEquals(0, db.disconnect());
	}

	@Test
	public void testGetEndDates1() throws SQLException 
	{
		String endDate = "05/05/2019";
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_wed")).thenReturn(endDate);
		String temp = db.fetchEndWed(0);
		assertEquals("End dates match:", endDate, temp);
	}
	
	@Test
	public void testGetEndDates2() throws SQLException 
	{
		String endDate = "02/05/2019";
		String endDateDB = "02/06/2019";
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_wed")).thenReturn(endDateDB);
		String temp = db.fetchEndWed(0);
		assertNotEquals("End dates don't match:", endDate, temp);
	}

	@Test
	public void testGetCourses1() throws SQLException 
	{
		int courseID = 1001;
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.next()).thenReturn(true,false);
		when(resultMock.getInt("course_id")).thenReturn(courseID);
		ArrayList<Integer> temp = db.getCourses();
		assertEquals("Get course list:", courseID, (int)temp.get(0));
	}

	@Test
	public void testGetCourses2() throws SQLException 
	{
		int courseID = 1001;
		int courseIDDB = 1002;
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.next()).thenReturn(true,false);
		when(resultMock.getInt("course_id")).thenReturn(courseIDDB);
		ArrayList<Integer> temp = db.getCourses();
		assertNotEquals("Get course list:", courseID, (int)temp.get(0));
	}
	
	@Test
	public void testFetchCourses1() throws SQLException 
	{
		int courseID = 1001;
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.next()).thenReturn(true,false);
		when(resultMock.getInt("course_id")).thenReturn(courseID);
		String temp = db.fetchCourses();
		String courseIDS = "1001,";
		assertEquals("Fetch courses:", courseIDS, temp);
	}
	
	@Test
	public void testFetchCourses2() throws SQLException 
	{
		int courseID = 1001;
		int courseIDDB = 1002;
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.next()).thenReturn(true,false);
		when(resultMock.getInt("course_id")).thenReturn(courseIDDB);
		String temp = db.fetchCourses();
		String courseIDS = "1001,";
		assertNotEquals("Fetch courses:", courseIDS, temp);
	}

	@Test
	public void testFetchCourseSubj1() throws SQLException 
	{
		String subject = "MATH";
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("course_subject")).thenReturn(subject);
		String temp = db.fetchCourseSubj(0);
		assertEquals("Fetch course subject:", subject, temp);
	}

	@Test
	public void testFetchCourseSubj2() throws SQLException 
	{
		String subject = "MATH";
		String subjectDB = "ENG";
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("course_subject")).thenReturn(subjectDB);
		String temp = db.fetchCourseSubj(0);
		assertNotEquals("Fetch course subject:", subject, temp);
	}

	
	@Test
	public void testFetchCourseName1() throws SQLException 
	{
		String name = "Mathematics";
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("course_name")).thenReturn(name);
		String temp = db.fetchCourseName(0);
		assertEquals("Fetch course name:", name, temp);
	}

	@Test
	public void testFetchCourseName2() throws SQLException 
	{
		String name = "Mathematics";
		String nameDB = "English";
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("course_name")).thenReturn(nameDB);
		String temp = db.fetchCourseName(0);
		assertNotEquals("Fetch course name:", name, temp);
	}
	
	@Test
	public void testFetchCourseSemester1() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("semester")).thenReturn("semester");
		assertEquals("semester", db.fetchCourseSemester(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchCourseSemester2() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("semester")).thenReturn("not_semester");
		String test = db.fetchCourseSemester(0);
		assertFalse("semester"==test);

	}

	@Test
	public void testFetchCourseStart1() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_date")).thenReturn("start_date");
		assertEquals("start_date", db.fetchCourseStart(0));

	}
	
	@Test
	public void testFetchCourseStart2() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_date")).thenReturn("not_start_date");
		String test = db.fetchCourseStart(0);
		assertFalse("start_date" == test);

	}

	@Test
	public void testFetchCourseEnd1() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_date")).thenReturn("end_date");
		assertEquals("end_date", db.fetchCourseEnd(0));
	}
	
	@Test
	public void testFetchCourseEnd2() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_date")).thenReturn("not_end_date");
		String test = db.fetchCourseEnd(0);
		assertFalse("end_date" == test);
	}

	@Test
	public void testFetchStartMon1() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_mon")).thenReturn("11:00");
		assertEquals("11:00", db.fetchStartMon(0));
		//fail("Not yet implemented");
	}

	@Test
	public void testFetchStartMon2() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_mon")).thenReturn("11:00");
		String temp = db.fetchStartMon(0);
		assertFalse("12:00"==temp);
	}
	
	
	@Test
	public void testFetchEndMon1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_mon")).thenReturn("12:00");
		assertEquals("12:00", db.fetchEndMon(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchEndMon2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_mon")).thenReturn("11:00");
		String temp = db.fetchEndMon(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchStartTue1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_tue")).thenReturn("11:00");
		assertEquals("11:00", db.fetchStartTue(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchStartTue2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_tue")).thenReturn("11:00");
		String temp = db.fetchStartTue(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchEndTue1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_tue")).thenReturn("12:00");
		assertEquals("12:00", db.fetchEndTue(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchEndTue2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_tue")).thenReturn("11:00");
		String temp = db.fetchEndTue(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchStartWed1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_wed")).thenReturn("11:00");
		assertEquals("11:00", db.fetchStartWed(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchStartWed2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_wed")).thenReturn("11:00");
		String temp = db.fetchStartWed(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchEndWed1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_wed")).thenReturn("12:00");
		assertEquals("12:00", db.fetchEndWed(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchEndWed2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_wed")).thenReturn("11:00");
		String temp = db.fetchEndWed(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchStartThu1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_thu")).thenReturn("11:00");
		assertEquals("11:00", db.fetchStartThu(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchStartThu2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_thu")).thenReturn("11:00");
		String temp = db.fetchStartThu(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchEndThu1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_thu")).thenReturn("12:00");
		assertEquals("12:00", db.fetchEndThu(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchEndThu2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_thu")).thenReturn("11:00");
		String temp = db.fetchStartThu(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchStartFri1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_fri")).thenReturn("11:00");
		assertEquals("11:00", db.fetchStartFri(0));
		//fail("Not yet implemented");
	}

	@Test
	public void testFetchStartFri2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("start_fri")).thenReturn("11:00");
		String temp = db.fetchStartFri(0);
		assertFalse("12:00"==temp);
	}
	
	@Test
	public void testFetchEndFri1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_fri")).thenReturn("12:00");
		assertEquals("12:00", db.fetchEndFri(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchEndFri2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.getResultSet()).thenReturn(resultMock);
		when(resultMock.getString("end_fri")).thenReturn("11:00");
		String temp = db.fetchEndFri(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchStartSat1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.executeQuery("SELECT start_sat FROM Class100 WHERE course_id = " +0 +";")).thenReturn(resultMock);
		when(resultMock.getString("start_sat")).thenReturn("11:00");
		assertEquals("11:00", db.fetchStartSat(0));
		//fail("Not yet implemented");
	}
	
	@Test
	public void testFetchStartSat2() throws SQLException {
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.executeQuery("SELECT start_sat FROM Class100 WHERE course_id = " +0 +";")).thenReturn(resultMock);
		when(resultMock.getString("start_sat")).thenReturn("11:00");
		String temp = db.fetchStartSat(0);
		assertFalse("12:00"==temp);
	}

	@Test
	public void testFetchEndSat1() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.executeQuery("SELECT end_sat FROM Class100 WHERE course_id = " +0 +";")).thenReturn(resultMock);
		when(resultMock.getString("end_sat")).thenReturn("12:00");
		assertEquals("12:00", db.fetchEndSat(0));
		//fail("Not yet implemented");
	}
	
	public void testFetchEndSat2() throws SQLException{
		when(connectMock.createStatement()).thenReturn(statementMock);
		when(statementMock.executeQuery("SELECT end_sat FROM Class100 WHERE course_id = " +0 +";")).thenReturn(resultMock);
		when(resultMock.getString("end_sat")).thenReturn("12:00");
		String temp = db.fetchEndSat(0);
		assertFalse("12:00"==temp);
	}
}