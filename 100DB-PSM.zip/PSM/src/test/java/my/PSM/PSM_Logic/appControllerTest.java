package my.PSM.PSM_Logic;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.security.Permission;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import static org.hamcrest.CoreMatchers.*;

import my.PSM.PSM_Interface.LoginForm;
import my.PSM.PSM_Storage.DBConnection;


public class appControllerTest extends SecurityManager
{

	@Mock
	DBConnection dbMock;
	@Mock
	InterfaceController icMock;
	@Mock
	Authenticate authMock;
	
	@Mock
	LoginForm logMock;
	
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();
	private SecurityManager securityManager;
	private appController app1;
    private String username;
    private String password;
	
	@Before
	public void setUp() throws Exception {
		dbMock = mock(DBConnection.class);
		icMock = mock(InterfaceController.class);
		authMock = mock(Authenticate.class);
		logMock = mock(LoginForm.class);
		app1 = new appController();
		
		appController.setDependency(dbMock);
		appController.setDependency(icMock);
		appController.setDependency(authMock);	
	    securityManager = System.getSecurityManager();
	    System.setSecurityManager(new NoExitSecurityManager());
        username = "clarkep";
        password = "12345";
	}

	@After
	public void tearDown() throws Exception 
	{
		app1 = null;
	    System.setSecurityManager(securityManager);
        username = null;
        password = null;
		dbMock = null;
		icMock = null;
		authMock = null;
		logMock = null;
	}


	@Test	
	/*
	 * Test Id: AC_AppController_001
	 * Test Purpose: To test the App controller's instance constructor
	 * 					initializes the variable hr.
	 * Setup: Create a new instance of appController
	 * 			appController app1 = new appController();
	 * Input: appController app1 = new appController();
	 * 				hr = 0
	 * 			app1.returnHr();
	 * Expected Output: true
	 */
	public void testAppController1() {
		assertEquals("Hour: ", 0, app1.returnHr());
	}
	

	@Test
	/*
	 * Test Id: AC_AppController_002
	 * Test Purpose: To test the App controller's instance constructor
	 * 					initializes the variable min.
	 * Setup: Create a new instance of appController
	 * 			appController app1 = new appController();
	 * Input: appController app1 = new appController();
	 * 				min = 0
	 * 			app1.returnHr();
	 * Expected Output: true
	 */
	public void testAppController2() {
		assertEquals("Minute", 0, app1.returnMin());
	}

	@Test
	/*
	 * Test Id: AC_CheckClear_001
	 * Test Purpose: To test if checkClear correctly checks if the dateList is 
	 * 					valid. Meaning the dates within dateList are less
	 * 					than today's date.
	 * Setup: Initialize an arraylist of strings (dateList).
	 * 			Add the date "01/05/19"
	 * 			Add the date "04/25/18"
	 * Input: dateList ("01/05/19","04/25/18")
	 * Expected Output: True, dates are valid
	 */
	public void testCheckClear1() {
		ArrayList<String> dateList = new ArrayList<String>();
		dateList.add("01/05/19");
		dateList.add("04/25/18");
		when(dbMock.getEndDates()).thenReturn(dateList);
		
		assertTrue("The dates are valid: ",appController.checkClear());
	}

	@Test
	/*
	 * Test Id: AC_CheckClear_002
	 * Test Purpose: To test if checkClear correctly checks if the dateList is 
	 * 					valid. Meaning the dates within dateList are less
	 * 					than today's date.
	 * Setup: Initialize an arraylist of strings (dateList).
	 * 			Add the date "05/05/19"
	 * 			Add the date "04/25/18"
	 * Input: dateList ("05/05/19","04/25/18")
	 * Expected Output: False, dates are not valid.
	 */
	public void testCheckClear2() {
		ArrayList<String> dateList = new ArrayList<String>();
		dateList.add("05/05/19");
		dateList.add("04/25/18");
		when(dbMock.getEndDates()).thenReturn(dateList);
		
		assertFalse("The dates are not valid", appController.checkClear());
	}
	
	@Test
	/*
	 * Test Id: AC_AutoClear_001
	 * Test Purpose: To test if checkClear correctly checks if the dateList is 
	 * 					valid. Meaning the dates within dateList are less
	 * 					than today's date.
	 * Setup: Initialize an arraylist of strings (dateList).
	 * 			Add the date "01/05/19"
	 * 			Add the date "04/25/18"
	 * Input: dateList ("01/05/19","04/25/18")
	 * Expected Output: True, dates are valid
	 */
	public void testAutoClear1() {
		String timer = "08:15";
		appController.timerParser(timer);
		
		assertEquals("Hour", 8, app1.returnHr());
		assertEquals("Minute", 15, app1.returnMin());
		
		ArrayList<String> dateList = new ArrayList<String>();
		dateList.add("01/05/19");
		dateList.add("04/25/18");
		when(dbMock.getEndDates()).thenReturn(dateList);
		
		assertTrue("The dates are valid: ",appController.checkClear());
	}
	
	@Test
	/*
	 * Test Id: AC_CheckTimes_001
	 * Test Purpose: To test if timers are created on today's date, when
	 * 					a course has a start(20:05), and end time (22:00)
	 * 					on today's date.
	 * 					Will either be: Monday, Tuesday,..., Saturday.
	 * 	
	 * Setup:	Initialize an Integer ArrayList with 
	 * 			One course. ID: 1001 
	 * 			Define Database String return values for one course, ID 1001:
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: 20:05
	 * 				Monday End Time: 22:00
 	 * 				Tuesday Start Time: 20:05
	 * 				Tuesday End Time: 22:00
	 * 				Wednesday Start Time: 20:05
	 * 				Wednesday End Time: 22:00
	 *  			Thursday Start Time: 20:05
	 * 				Thursday End Time: 22:00
	 *  			Friday Start Time: 20:05
	 * 				Friday End Time: 22:00
	 *  			Saturday Start Time: 20:05
	 * 				Saturday End Time: 22:00
	 * 			Mock the database to return these values when called
	 * 			from checkTimes function
	 * 
	 * Input: 		Course: 1001
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: 20:05
	 * 				Monday End Time: 22:00
 	 * 				Tuesday Start Time: 20:05
	 * 				Tuesday End Time: 22:00
	 * 				Wednesday Start Time: 20:05
	 * 				Wednesday End Time: 22:00
	 *  			Thursday Start Time: 20:05
	 * 				Thursday End Time: 22:00
	 *  			Friday Start Time: 20:05
	 * 				Friday End Time: 22:00
	 *  			Saturday Start Time: 20:05
	 * 				Saturday End Time: 22:00
	 * Expected Output: False(isNull), a valid time was entered for Today's day.
	 */
	public void testCheckTimes1() 
	{
		ArrayList<Integer> courseList = new ArrayList<Integer>();
		courseList.add(1001);
		
		String defSub = "MAD";
		String defSemester = "Fall";
		String defCourseName = "Math";
		String defCourseStart = "01/03/19";
		String defCourseEnd = "05/05/19";
		String defMonStart = "20:05";
		String defMonEnd = "22:00";
		String defTueStart = "20:05";
		String defTueEnd = "22:00";
		String defWedStart = "20:05";
		String defWedEnd = "22:00";
		String defThuStart = "20:05";
        String defThuEnd = "22:00";
        String defFriStart = "20:05";
        String defFriEnd = "22:00";
        String defSatStart = "20:05";
        String defSatEnd = "22:00";
        
		when(dbMock.getCourses()).thenReturn(courseList);
		when(dbMock.fetchCourseSubj(courseList.get(0))).thenReturn(defSub);
		when(dbMock.fetchCourseSemester(courseList.get(0))).thenReturn(defSemester);
		when(dbMock.fetchCourseName(courseList.get(0))).thenReturn(defCourseName);
		when(dbMock.fetchCourseStart(courseList.get(0))).thenReturn(defCourseStart);
		when(dbMock.fetchCourseEnd(courseList.get(0))).thenReturn(defCourseEnd);
		when(dbMock.fetchStartMon(courseList.get(0))).thenReturn(defMonStart);
		when(dbMock.fetchEndMon(courseList.get(0))).thenReturn(defMonEnd);
		when(dbMock.fetchStartTue(courseList.get(0))).thenReturn(defTueStart);
		when(dbMock.fetchEndTue(courseList.get(0))).thenReturn(defTueEnd);
		when(dbMock.fetchStartWed(courseList.get(0))).thenReturn(defWedStart);
		when(dbMock.fetchEndWed(courseList.get(0))).thenReturn(defWedEnd);
		when(dbMock.fetchStartThu(courseList.get(0))).thenReturn(defThuStart);
		when(dbMock.fetchEndThu(courseList.get(0))).thenReturn(defThuEnd);
		when(dbMock.fetchStartFri(courseList.get(0))).thenReturn(defFriStart);
		when(dbMock.fetchEndFri(courseList.get(0))).thenReturn(defFriEnd);
		when(dbMock.fetchStartSat(courseList.get(0))).thenReturn(defSatStart);
		when(dbMock.fetchEndSat(courseList.get(0))).thenReturn(defSatEnd);
		
	
		assertTrue("Time is valid: ", appController.checkTimes());	
	}

	@Test
	/*
	 * Test Id: AC_CheckTimes_002
	 * Test Purpose: To test if timers are created on today's date, when
	 * 					a course has NO start, or end time
	 * 					on today's date.
	 * 					Will either be: Monday, Tuesday,..., Saturday.
	 * 	
	 * Setup:	Initialize an Integer ArrayList with 
	 * 			One course. ID: 1001 
	 * 			Define Database String return values for one course, ID 1001:
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: null
	 * 				Monday End Time: null
 	 * 				Tuesday Start Time: null
	 * 				Tuesday End Time: null
	 * 				Wednesday Start Time: null
	 * 				Wednesday End Time: null
	 *  			Thursday Start Time: null
	 * 				Thursday End Time: null
	 *  			Friday Start Time: null
	 * 				Friday End Time: null
	 *  			Saturday Start Time: null
	 * 				Saturday End Time: null
	 * 			Mock the database to return these values when called
	 * 			from checkTimes function
	 * 
	 * Input: 		Course: 1001
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: null
	 * 				Monday End Time: null
 	 * 				Tuesday Start Time: null
	 * 				Tuesday End Time: null
	 * 				Wednesday Start Time: null
	 * 				Wednesday End Time: null
	 *  			Thursday Start Time: null
	 * 				Thursday End Time: null
	 *  			Friday Start Time: null
	 * 				Friday End Time: null
	 *  			Saturday Start Time: null
	 * 				Saturday End Time: null
	 * Expected Output: True(isNull), no valid time is found
	 */
	public void testCheckTimes2() 
	{
		ArrayList<Integer> courseList = new ArrayList<Integer>();
		courseList.add(1001);
		
		String defSub = "MAD";
		String defSemester = "Fall";
		String defCourseName = "Math";
		String defCourseStart = "01/03/19";
		String defCourseEnd = "05/05/19";
		String defMonStart = "";
		String defMonEnd = "";
		String defTueStart = "";
		String defTueEnd = "";
		String defWedStart = "";
		String defWedEnd = "";
		String defThuStart = "";
        String defThuEnd = "";
        String defFriStart = "";
        String defFriEnd = "";
        String defSatStart = "";
        String defSatEnd = "";
        
		when(dbMock.getCourses()).thenReturn(courseList);
		when(dbMock.fetchCourseSubj(courseList.get(0))).thenReturn(defSub);
		when(dbMock.fetchCourseSemester(courseList.get(0))).thenReturn(defSemester);
		when(dbMock.fetchCourseName(courseList.get(0))).thenReturn(defCourseName);
		when(dbMock.fetchCourseStart(courseList.get(0))).thenReturn(defCourseStart);
		when(dbMock.fetchCourseEnd(courseList.get(0))).thenReturn(defCourseEnd);
		when(dbMock.fetchStartMon(courseList.get(0))).thenReturn(defMonStart);
		when(dbMock.fetchEndMon(courseList.get(0))).thenReturn(defMonEnd);
		when(dbMock.fetchStartTue(courseList.get(0))).thenReturn(defTueStart);
		when(dbMock.fetchEndTue(courseList.get(0))).thenReturn(defTueEnd);
		when(dbMock.fetchStartWed(courseList.get(0))).thenReturn(defWedStart);
		when(dbMock.fetchEndWed(courseList.get(0))).thenReturn(defWedEnd);
		when(dbMock.fetchStartThu(courseList.get(0))).thenReturn(defThuStart);
		when(dbMock.fetchEndThu(courseList.get(0))).thenReturn(defThuEnd);
		when(dbMock.fetchStartFri(courseList.get(0))).thenReturn(defFriStart);
		when(dbMock.fetchEndFri(courseList.get(0))).thenReturn(defFriEnd);
		when(dbMock.fetchStartSat(courseList.get(0))).thenReturn(defSatStart);
		when(dbMock.fetchEndSat(courseList.get(0))).thenReturn(defSatEnd);
		
	
		assertTrue("Time is not valid", appController.checkTimes());	
	}
	
	
	@Test
	/*
	 * Test Id: AC_GetData_001
	 * Test Purpose: To test if the course data is stored correctly in 
	 * 					the local variables.
	 * 	
	 * Setup:	Initialize the following variables containing course information: 
	 * 				Course ID: 1001 
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: 20:05
	 * 				Monday End Time: 22:00
 	 * 				Tuesday Start Time: 20:05
	 * 				Tuesday End Time: 22:00
	 * 				Wednesday Start Time: 20:05
	 * 				Wednesday End Time: 22:00
	 *  			Thursday Start Time: 20:05
	 * 				Thursday End Time: 22:00
	 *  			Friday Start Time: 20:05
	 * 				Friday End Time: 22:00
	 *  			Saturday Start Time: 20:05
	 * 				Saturday End Time: 22:00
	 * 
	 * 				Create a string array to compare
	 * 				the stored values in appController
	 * 				against the expected values (Stored in the string).
	 * 			Mock the database to return these values when called
	 * 			from getData()
	 * 
	 * Input: 		Course: 1001
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: 20:05
	 * 				Monday End Time: 22:00
 	 * 				Tuesday Start Time: 20:05
	 * 				Tuesday End Time: 22:00
	 * 				Wednesday Start Time: 20:05
	 * 				Wednesday End Time: 22:00
	 *  			Thursday Start Time: 20:05
	 * 				Thursday End Time: 22:00
	 *  			Friday Start Time: 20:05
	 * 				Friday End Time: 22:00
	 *  			Saturday Start Time: 20:05
	 * 				Saturday End Time: 22:00
	 * Expected Output: True, local values match with user input (Obtained from Database)
	 * 					(Assuming the database returns the correct values).
	 */
	public void testGetData1()
	{
		int courseList = 1001;
		String defSub = "MAD";
		String defSemester = "Fall";
		String defCourseName = "Math";
		String defCourseStart = "01/03/19";
		String defCourseEnd = "05/05/19";
		String defMonStart = "20:05";
		String defMonEnd = "22:00";
		String defTueStart = "20:05";
		String defTueEnd = "22:00";
		String defWedStart = "20:05";
		String defWedEnd = "22:00";
		String defThuStart = "20:05";
        String defThuEnd = "22:00";
        String defFriStart = "20:05";
        String defFriEnd = "22:00";
        String defSatStart = "20:05";
        String defSatEnd = "22:00";
        

        
		when(dbMock.fetchCourseSubj(courseList)).thenReturn(defSub);
		when(dbMock.fetchCourseSemester(courseList)).thenReturn(defSemester);
		when(dbMock.fetchCourseName(courseList)).thenReturn(defCourseName);
		when(dbMock.fetchCourseStart(courseList)).thenReturn(defCourseStart);
		when(dbMock.fetchCourseEnd(courseList)).thenReturn(defCourseEnd);
		when(dbMock.fetchStartMon(courseList)).thenReturn(defMonStart);
		when(dbMock.fetchEndMon(courseList)).thenReturn(defMonEnd);
		when(dbMock.fetchStartTue(courseList)).thenReturn(defTueStart);
		when(dbMock.fetchEndTue(courseList)).thenReturn(defTueEnd);
		when(dbMock.fetchStartWed(courseList)).thenReturn(defWedStart);
		when(dbMock.fetchEndWed(courseList)).thenReturn(defWedEnd);
		when(dbMock.fetchStartThu(courseList)).thenReturn(defThuStart);
		when(dbMock.fetchEndThu(courseList)).thenReturn(defThuEnd);
		when(dbMock.fetchStartFri(courseList)).thenReturn(defFriStart);
		when(dbMock.fetchEndFri(courseList)).thenReturn(defFriEnd);
		when(dbMock.fetchStartSat(courseList)).thenReturn(defSatStart);
		when(dbMock.fetchEndSat(courseList)).thenReturn(defSatEnd);
	
    	String[] values = 
		{
	        defSub,
	        defSemester,
	        defCourseName,
	        defCourseStart,
	        defCourseEnd,
	        defMonStart,
	        defMonEnd,
	        defTueStart,
	        defTueEnd,
	        defWedStart,
	        defWedEnd,
	        defThuStart,
	        defThuEnd,
	        defFriStart,
	        defFriEnd,
	        defSatStart,
	        defSatEnd
		};
    	
		appController.getData(courseList);
		assertArrayEquals(values,appController.GetDataInfo());
	}
	
	@Test
	/*
	 * Test Id: AC_GetData_002
	 * Test Purpose: To test if the course data is stored incorrectly in 
	 * 					the local variables, if the database returns
	 * 					the wrong values
	 * 
	 * Setup:	Initialize the following variables containing course information: 
	 * 				Course ID: 1001
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: 20:05
	 * 				Monday End Time: 22:00
 	 * 				Tuesday Start Time: 20:05
	 * 				Tuesday End Time: 22:00
	 * 				Wednesday Start Time: 20:05
	 * 				Wednesday End Time: 22:00
	 *  			Thursday Start Time: 20:05
	 * 				Thursday End Time: 22:00
	 *  			Friday Start Time: 20:05
	 * 				Friday End Time: 22:00
	 *  			Saturday Start Time: 20:05
	 * 				Saturday End Time: 22:00
	 * 
	 * 				Create a string array containing 
	 * 				the stored values in appController
	 * 				against the expected values (Stored in the string).
	 * 			Mock the database to return these values when called
	 * 			from getData()
	 * 				Change defSatEnd = "10:00"
	 * 
	 * Input: 		Course: 1001
	 * 				Subject: MAD
	 * 				Semester: Fall
	 * 				Course Name: Math
	 * 				Course Start: 01/03/19
	 * 				Course End: 05/05/19
	 * 				Monday Start Time: 20:05
	 * 				Monday End Time: 22:00
 	 * 				Tuesday Start Time: 20:05
	 * 				Tuesday End Time: 22:00
	 * 				Wednesday Start Time: 20:05
	 * 				Wednesday End Time: 22:00
	 *  			Thursday Start Time: 20:05
	 * 				Thursday End Time: 22:00
	 *  			Friday Start Time: 20:05
	 * 				Friday End Time: 22:00
	 *  			Saturday Start Time: 20:05
	 * 				Saturday End Time: 22:00
	 * 			
	 * 				CHANGE Staurday End Time: 10:00 (Simulate DB wrong return)
	 * Expected Output: False, values from database do not match with user input.
	 * 					(Assuming the database returns the incorrect values).
	 */
	public void testGetData2()
	{
		int courseList = 1001;
		String defSub = "MAD";
		String defSemester = "Fall";
		String defCourseName = "Math";
		String defCourseStart = "01/03/19";
		String defCourseEnd = "05/05/19";
		String defMonStart = "20:05";
		String defMonEnd = "22:00";
		String defTueStart = "20:05";
		String defTueEnd = "22:00";
		String defWedStart = "20:05";
		String defWedEnd = "22:00";
		String defThuStart = "20:05";
        String defThuEnd = "22:00";
        String defFriStart = "20:05";
        String defFriEnd = "22:00";
        String defSatStart = "20:05";
        String defSatEnd = "22:00";
        
        
		when(dbMock.fetchCourseSubj(courseList)).thenReturn(defSub);
		when(dbMock.fetchCourseSemester(courseList)).thenReturn(defSemester);
		when(dbMock.fetchCourseName(courseList)).thenReturn(defCourseName);
		when(dbMock.fetchCourseStart(courseList)).thenReturn(defCourseStart);
		when(dbMock.fetchCourseEnd(courseList)).thenReturn(defCourseEnd);
		when(dbMock.fetchStartMon(courseList)).thenReturn(defMonStart);
		when(dbMock.fetchEndMon(courseList)).thenReturn(defMonEnd);
		when(dbMock.fetchStartTue(courseList)).thenReturn(defTueStart);
		when(dbMock.fetchEndTue(courseList)).thenReturn(defTueEnd);
		when(dbMock.fetchStartWed(courseList)).thenReturn(defWedStart);
		when(dbMock.fetchEndWed(courseList)).thenReturn(defWedEnd);
		when(dbMock.fetchStartThu(courseList)).thenReturn(defThuStart);
		when(dbMock.fetchEndThu(courseList)).thenReturn(defThuEnd);
		when(dbMock.fetchStartFri(courseList)).thenReturn(defFriStart);
		when(dbMock.fetchEndFri(courseList)).thenReturn(defFriEnd);
		when(dbMock.fetchStartSat(courseList)).thenReturn(defSatStart);
		when(dbMock.fetchEndSat(courseList)).thenReturn(defSatEnd);
	
        defSatEnd = "10:00";
    	String[] values = 
		{
	        defSub,
	        defSemester,
	        defCourseName,
	        defCourseStart,
	        defCourseEnd,
	        defMonStart,
	        defMonEnd,
	        defTueStart,
	        defTueEnd,
	        defWedStart,
	        defWedEnd,
	        defThuStart,
	        defThuEnd,
	        defFriStart,
	        defFriEnd,
	        defSatStart,
	        defSatEnd
		};
    	
		appController.getData(courseList);
		assertThat(values, not( appController.GetDataInfo()));
	}	

	
	@Test
	/*
	 * Test Id: AC_TimerParser_001
	 * Test Purpose: Test if the timeParser method will appropriately
	 * 				set the hr, and min variables to 
	 * 				hr = 8;
	 * 				min = 15;
	 * 				when the string "08:15" is passed in.
	 * Setup: 
	 * 			Inititialize the timer string as
	 * 			timer = "08:15"
	 *			Call the timerParser method in appController
	 * Input:	"08:15"
	 * Expected Output: Hour: 8, Minute: 15 
	 */
	public void testTimerParser1() 
	{
		String timer = "08:15";
		appController.timerParser(timer);
		
		assertEquals("Hour", 8, app1.returnHr());
		assertEquals("Minute", 15, app1.returnMin());
	}
	
	@Test
	/*
	 * Test Id: AC_TimerParser_002
	 * Test Purpose: Test if the timeParser method will throw an exception
	 * 				when the timer variable is not formatted as hh:mm.
	 * 				timer = 008:15
	 * Setup: 
	 * 			Initialize the timer string as
	 * 			timer = "008:15"
	 *			Call the timerParser method in appController
	 * Input:	"008:15"
	 * Expected Output: NumberFormatException exception thrown.
	 */
	public void testTimerParser2() 
	{
		String timer = "008:15";

	    exceptionRule.expect(NumberFormatException.class);
		
	    appController.timerParser(timer);
	}

	
	@Test
	/*
	 * Test Id: AC_DateParser_001
	 * Test Purpose: Test if the dateParser method will appropriately
	 * 				set the month, date, and year variables to
	 * 				month = 1;
	 * 				date = 4;
	 * 				year = 15;
	 * 				when the string "01/04/15" is passed in.
	 * Setup: 
	 * 			Initialize the timer string as
	 * 			timer = "01/04/15"
	 *			Call the dateParser method in appController
	 * Input:	"01/04/15"
	 * Expected Output: Month = 1, Day = 4, Year = 15
	 */
	public void testDateParser1() 
	{
		String timer = "01/04/15";
		appController.dateParser(timer);
		
		assertEquals("Month", 1, appController.GetClearMonth());
		assertEquals("Day", 4, appController.GetClearDate());
		assertEquals("Year", 15, appController.GetClearYear());
	}
	
	@Test
	/*
	 * Test Id: AC_DateParser_002
	 * Test Purpose: Test if the dateParser method will appropriately
	 * 				set the month, date, and year variables to
	 * 				month = 1;
	 * 				date = 4;
	 * 				year = 15;
	 * 				when the string "1/4/15" is passed in.
	 * Setup: 
	 * 			Initialize the timer string as
	 * 			timer = "01/04/15"
	 *			Call the dateParser method in appController
	 * Input:	"01/04/15"
	 * Expected Output: NumberFormatException, since this method 
	 * 					has no input validation
	 */
	public void testDateParser2() 
	{
		String timer = "1/4/15";

	    exceptionRule.expect(NumberFormatException.class);
	    
		appController.dateParser(timer);
	}
	
	
	@Test
	/*
	 * Test Id: AC_ReturnHr_001
	 * Test Purpose: Test if the returnHR method returns the correct
	 * 					hr value which is 0 at initialization.
	 * Setup: Create an instance of appController
	 * 			appController app1 = new appController()
	 * Input: new appController instance
	 * Expected Output: 0
	 */
	public void testReturnHr1() 
	{
		assertEquals("Hour", 0, app1.returnHr());
	}
	
	@Test
	/*
	 * Test Id: AC_ReturnHr_002
	 * Test Purpose: Test if the returnHR method returns the icorrect
	 * 					hr value. It is 0 at initialization.
	 * Setup: Create an instance of appController
	 * 			appController app1 = new appController()
	 * Input: new appController instance
	 * Expected Output: 0
	 */
	public void testReturnHr2() 
	{
		assertNotEquals("Hour", 1, app1.returnHr());
	}
	

	@Test
	/*
	 * Test Id: AC_ReturnMin_001
	 * Test Purpose: Test if the returnMin method returns the correct
	 * 					min value which is 0 at initialization.
	 * Setup: Create an instance of appController
	 * 			appController app1 = new appController()
	 * Input: new appController instance
	 * Expected Output: 0
	 */
	public void testReturnMin1() 
	{
		assertEquals("Minute", 0, app1.returnMin());
	}
	
	@Test
	/*
	 * Test Id: AC_ReturnMin_001
	 * Test Purpose: Test if the returnMin method returns the incorrect
	 * 					min value. It is 0 at initialization.
	 * Setup: Create an instance of appController
	 * 			appController app1 = new appController()
	 * Input: new appController instance
	 * Expected Output: 0
	 */
	public void testReturnMin2() 
	{
		assertNotEquals("Minute", 1, app1.returnMin());
	}

	@Test
	/*
	 * Test Id: AC_GetEndTime_001
	 * Test Purpose: To test if the end of the class at 11:15 is returned
	 * 					as a Date object
	 * Setup: 
	 * 			Create a GregorianCalendar object(newDate) to hold date information
	 * 			Initialize hours = 23, and minutes = 15
	 * 			Set the newDate object to todays date, at 23 hours and 14 minutes.
	 * Input: Hours = 23
	 * 			Minutes = 15
	 * Expected Output: Dates are the same
	 */
	public void testGetEndTime1() 
	{
		Calendar newDate = new GregorianCalendar();
		int hrs = 23;
		int min = 15;
		
		newDate.set(newDate.get(newDate.YEAR),newDate.get(newDate.MONTH), newDate.get(newDate.DATE), hrs, min - 1, 1);
		
		assertEquals("Date same", appController.getEndTime(hrs, min), newDate.getTime());
	}
	
	@Test
	/*
	 * Test Id: AC_GetEndTime_002
	 * Test Purpose: To test if the end of the class at 11:15 is returned
	 * 					as a Date object, if the hours and minutes are switched
	 * 					in the parameters
	 *
	 * Setup: 
	 * 			Create a GregorianCalendar object(newDate) to hold date information
	 * 			Initialize hours = 16, and minutes = 36
	 * 			Set the newDate object to todays date, at 16 hours and 36 minutes.
	 * Input: Hours = 16
	 * 			Minutes = 36
	 * Expected Output: Hours and minutes are not validated, so dates
	 * 					will not be the same
	 */
	public void testGetEndTime2() 
	{
		Calendar newDate = new GregorianCalendar();
		int hrs = 16;
		int min = 36;
		
		newDate.set(newDate.get(newDate.YEAR),newDate.get(newDate.MONTH), newDate.get(newDate.DATE), hrs, min - 1, 1);
		
		assertNotEquals("Date same", appController.getEndTime(min, hrs), newDate.getTime());

	}

	
	@Test
	/*
	 * Test Id: AC_Get15BeforeEnd_001
	 * Test Purpose: To test if 15 minutes before the end of the class at 11:15 is returned
	 * 					as a Date object.
	 *
	 * Setup: 
	 * 			Create a GregorianCalendar object(newDate) to hold date information
	 * 			Initialize hours = 23, and minutes = 15
	 * 			Set the newDate object to todays date, at 23 hours and 00 minutes.
	 * Input: Hours = 23
	 * 			Minutes = 15
	 * Expected Output: Dates match
	 */
	public void testGet15BeforeEnd1() 
	{
		Calendar newDate = new GregorianCalendar();
		int hrs = 23;
		int min = 15;
		
		newDate.set(newDate.get(newDate.YEAR),newDate.get(newDate.MONTH), newDate.get(newDate.DATE), hrs, min - 15, 1);
		boolean check = appController.get15BeforeEnd(hrs,min).equals(newDate.getTime());
		assertTrue("Date same - 15 minutes", check);
	}

	@Test
	/*
	 * Test Id: AC_Get15BeforeEnd_002
	 * Test Purpose: To test if 15 minutes before the end of the class at 11:15 is returned
	 * 					as a Date object, if the hours and minutes are switched
	 * 					in the parameters
	 *
	 * Setup: 
	 * 			Create a GregorianCalendar object(newDate) to hold date information
	 * 			Initialize hours = 16, and minutes = 36
	 * 			Set the newDate object to todays date, at 16 hours and 36 minutes.
	 * Input: Hours = 36
	 * 			Minutes = 16
	 * Expected Output: Dates do not match, since there is no input validation.
	 */
	public void testGet15BeforeEnd2() 
	{
		Calendar newDate = new GregorianCalendar();
		int hrs = 16;
		int min = 36;
		
		newDate.set(newDate.get(newDate.YEAR),newDate.get(newDate.MONTH), newDate.get(newDate.DATE), hrs, min - 15, 1);
		
		assertNotEquals("Date same - 15 minutes", appController.get15BeforeEnd(min, hrs), newDate.getTime());
	}

	
	@Test
	/*
	 * Test Id: AC_Get5BeforeEnd_001
	 * Test Purpose: To test if 5 minutes before the end of the class at 11:15 is returned
	 * 					as a Date object.
	 *
	 * Setup: 
	 * 			Create a GregorianCalendar object(newDate) to hold date information
	 * 			Initialize hours = 23, and minutes = 15
	 * 			Set the newDate object to todays date, at 23 hours and 00 minutes.
	 * Input: Hours = 23
	 * 			Minutes = 15
	 * Expected Output: Dates match
	 */
	public void testGet5BeforeEnd1() 
	{
		Calendar newDate = new GregorianCalendar();
		int hrs = 23;
		int min = 15;
		
		newDate.set(newDate.get(newDate.YEAR),newDate.get(newDate.MONTH), newDate.get(newDate.DATE), hrs, min - 5, 1);
		
		assertEquals("Date same - 5 minutes", appController.get5BeforeEnd(hrs,min), newDate.getTime());

	}

	@Test
	/*
	 * Test Id: AC_Get5BeforeEnd_002
	 * Test Purpose: To test if 5 minutes before the end of the class at 11:15 is returned
	 * 					as a Date object, if the hours and minutes are switched
	 * 					in the parameters
	 *
	 * Setup: 
	 * 			Create a GregorianCalendar object(newDate) to hold date information
	 * 			Initialize hours = 16, and minutes = 36
	 * 			Set the newDate object to todays date, at 16 hours and 36 minutes.
	 * Input: Hours = 36
	 * 			Minutes = 16
	 * Expected Output: Dates do not match, since there is no input validation.
	 */
	public void testGet5BeforeEnd2() 
	{
		Calendar newDate = new GregorianCalendar();
		int hrs = 16;
		int min = 36;
		
		newDate.set(newDate.get(newDate.YEAR),newDate.get(newDate.MONTH), newDate.get(newDate.DATE), hrs, min - 5, 1);
		
		assertNotEquals("Date same - 5 minutes", appController.get5BeforeEnd(min,hrs), newDate.getTime());

	}

	
	@Test
	/*
	 * Test Id: AC_TryLogIn_001
	 * Test Purpose:
	 *
	 * Setup: 
	 * Input:
	 * 	
	 * Expected Output: 
	 */	
	public void testTryLogIn1()
	{
		String username = "pClarke";
		String password = "12345";
		
		doNothing().when(icMock).Initiate_Login_Form();
		
		icMock.log = logMock;
		when(icMock.log.dataReceived()).thenReturn(true);
		when(dbMock.connect(username,password)).thenReturn(0);
		when(icMock.log.dataReceived()).thenReturn(true);
		when(icMock.log.getUsername()).thenReturn(username);
		when(icMock.log.getPassword()).thenReturn(password);
		when(authMock.validate_Login()).thenReturn(true);
		
		assertTrue(appController.TryLogIn());
	}
	
	@Test
	/*
	 * Test Id: AC_TryLogIn_002
	 * Test Purpose:
	 *
	 * Setup: 
	 * Input:
	 * 	
	 * Expected Output: 
	 */
	public void testTryLogIn2()
	{
		String username = "pClarke";
		String password = "12as5";
		icMock.log = logMock;
		
		doNothing().when(icMock).Initiate_Login_Form();
	
		
		when(icMock.log.dataReceived()).thenReturn(true);
		
		doNothing().when(icMock.log).setDataRec(false);		
		
		when(icMock.log.getUsername()).thenReturn(username);
		when(icMock.log.getPassword()).thenReturn(password);
		when(authMock.validate_Login()).thenReturn(false);
		doNothing().when(icMock).Initiate_IncorrectLogin();
		
		icMock.msg.ack= true;

		assertFalse(appController.TryLogIn());
	}
	
	
	protected static class ExitException extends SecurityException {
	    private static final long serialVersionUID = -1982617086752946683L;
	    public final int status;

	    public ExitException(int status) {
	        super("There is no escape!");
	        this.status = status;
	    }
	}

    private static class NoExitSecurityManager extends SecurityManager 
    {
        @Override
        public void checkPermission(Permission perm) 
        {
            // allow anything.
        }
        @Override
        public void checkPermission(Permission perm, Object context) 
        {
            // allow anything.
        }
        @Override
        public void checkExit(int status) 
        {
            super.checkExit(status);
            throw new ExitException(status);
        }
    }

	/*
	 * Test Id: AC_TryLogIn_003
	 * Test Purpose: To test the function of the locked out feature
	 * after failing to log-in three times.
	 * Setup: Make any unnecessary calls do nothing. When stubber
	 * feeds the method information.
	 * Input: Entered pClarke and 12as5 three times.
	 * 	
	 * Expected Output: System.exit(0), system exit.
	 */
    @Test
    public void testTryLogIn3() throws Exception 
    {
		String username = "pClarke";
		String password = "12as5";
		icMock.log = logMock;
		doNothing().when(icMock).Initiate_Login_Form();
	
		
		when(icMock.log.dataReceived()).thenReturn(true);
		
		doNothing().when(icMock.log).setDataRec(false);		
		
		when(icMock.log.getUsername()).thenReturn(username);
		when(icMock.log.getPassword()).thenReturn(password);
		when(authMock.validate_Login()).thenReturn(false);
		doNothing().when(icMock).Initiate_IncorrectLogin();
		icMock.msg.ack= true;
		doNothing().when(icMock).Initiate_Login_Form();
		doNothing().when(icMock.log).setDataRec(false);	
		doNothing().when(icMock).Initiate_IncorrectLogin();
		doNothing().when(icMock).passwordLock();
		doNothing().when(icMock).icmsgack();
        try 
        {
        appController.TryLogIn();
        appController.TryLogIn();
        appController.TryLogIn();
        } catch (ExitException e) 
        {
            assertEquals("Exit status", 0, e.status);
        }
    }
    
    @Test
    public void testSetSemesterClear()
    {
    	Calendar autoClear = new GregorianCalendar();
    	appController.setSemesterClear(1997, 10, 28, 23, 59);
    	autoClear.set(1997, 10, 28, 23, 59);
    	Calendar cal1 = Calendar.getInstance();
    	cal1.setTime(appController.getDate2());
    	Calendar cal2 = Calendar.getInstance();
    	cal2.setTime(autoClear.getTime());
    	boolean isSameDay = cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) &&
    			               cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
    			                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    	assertTrue(isSameDay);
    }

    @Test
    public void testSetSemesterClear2()
    {
    	Calendar autoClear = new GregorianCalendar();
    	appController.setSemesterClear(1997, 10, 27, 23, 59);
    	autoClear.set(1997, 10, 28, 23, 59);
    	Date cal1 = appController.getDate2();
    	Date cal2 = autoClear.getTime();
    	boolean isSameDay = cal1.compareTo(cal2) == 0;
    	assertFalse(isSameDay);
    }

    @Test
    public void testGetTimeMillis()
    {
        Calendar setRun = new GregorianCalendar();
    	boolean isSame = ((long)appController.getTimeMillis())==((long)setRun.getTimeInMillis());
    	assertFalse(isSame);
    }
    @Test
    public void testLogIn1() throws Exception 
    {
		String username = "pClarke";
		String password = "12345";
		
		doNothing().when(icMock).Initiate_Login_Form();
		
		icMock.log = logMock;
		when(icMock.log.dataReceived()).thenReturn(true);
		when(dbMock.connect(username,password)).thenReturn(0);
		when(icMock.log.dataReceived()).thenReturn(true);
		when(icMock.log.getUsername()).thenReturn(username);
		when(icMock.log.getPassword()).thenReturn(password);
		when(authMock.validate_Login()).thenReturn(true);
		
        try 
        {
        appController.TryLogIn();
        } catch (ExitException e){}
        
		boolean check = appController.GetLoggedIn();
		assertTrue(check);
    }
    
    @Test
    public void testLogIn2() throws Exception
    {
		String username = "pClarke";
		String password = "12345";
		
		doNothing().when(icMock).Initiate_Login_Form();
		
		icMock.log = logMock;
		when(icMock.log.dataReceived()).thenReturn(true);
		when(dbMock.connect(username,password)).thenReturn(0);
		when(icMock.log.dataReceived()).thenReturn(true);
		when(icMock.log.getUsername()).thenReturn(username);
		when(icMock.log.getPassword()).thenReturn(password);
		when(authMock.validate_Login()).thenReturn(false);

		doNothing().when(icMock).Initiate_IncorrectLogin();
		icMock.msg.ack= true;
		doNothing().when(icMock).Initiate_Login_Form();
		doNothing().when(icMock.log).setDataRec(false);	
		doNothing().when(icMock).Initiate_IncorrectLogin();
		
        try 
        {
        appController.TryLogIn();
        } catch (ExitException e){}
    	//dbMock = mock(DBConnection.class);
    	//dbMock.disconnect();
    	//appController.setDependency(dbMock);
		boolean check = appController.GetLoggedIn();
		assertFalse(check);
    }
    
    @Test
    public void testGetCon()
    {
    	dbMock = mock(DBConnection.class);
    	appController.setDependency(dbMock);
		boolean check = appController.getCon().equals(dbMock);
		assertTrue(check);
    }
    @Test
    public void testSleep()
    {
    	appController.sleep(100);
    }

}


